#include <stdio.h>

#include <stdio.h>
int main( int agrc , char *argv[])
{
  char a=120;
  char b=12;
  char c;
  c=a+b;

  printf("120 + 12 equals %d\n", c);

return 0;

}